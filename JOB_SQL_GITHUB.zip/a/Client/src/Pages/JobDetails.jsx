import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Swal from "sweetalert2";

const JobDetails = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:3000/all-jobs/${id}`)
      .then((res) => res.json())
      .then((data) => setJob(data));
  }, [id]);

  if (!job) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 lg:px-24 py-12 bg-gray-50">
      {/* Header Section */}
      <div className="bg-white rounded-lg shadow-md p-8 mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            {job.jobTitle}
          </h1>
          <div className="flex flex-wrap items-center gap-4 mb-4">
            {/* Job Type Tags */}
            <span className="text-sm bg-blue-100 text-blue-600 font-semibold px-3 py-1 rounded">
              {job.employmentType}
            </span>
            <span className="text-sm bg-green-100 text-green-600 font-semibold px-3 py-1 rounded">
              {job.experienceLevel} Experience
            </span>
            <span className="text-sm bg-yellow-100 text-yellow-600 font-semibold px-3 py-1 rounded">
              {job.salaryType} Payment
            </span>
          </div>

          {/* Posting Date */}
          <div className="text-gray-600 text-md mb-4">
            <strong>Posted on:</strong>{" "}
            {job.postingDate
              ? new Date(job.postingDate).toLocaleDateString()
              : "N/A"}
          </div>
        </div>

        {/* Apply Button on the Right */}
        <button className="bg-blue hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg">
          Apply Now
        </button>
      </div>

      {/* Job Details Section */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left Column with Job Info */}
        <div className="bg-white rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-semibold mb-4">Job Information</h2>
          <p className="text-lg">
            <strong>Company:</strong> {job.companyName}
          </p>
          <p className="text-lg">
            <strong>Location:</strong> {job.jobLocation}
          </p>
          <p className="text-lg">
            <strong>Salary:</strong> ${job.minPrice} - ${job.maxPrice} per{" "}
            {job.salaryType}
          </p>
          <p className="text-lg">
            <strong>Experience Level:</strong> {job.experienceLevel}
          </p>
          <p className="text-lg">
            <strong>Skills:</strong>{" "}
            {Array.isArray(job.skills) && job.skills.length > 0
              ? job.skills.map((skill) => skill.value).join(", ")
              : "N/A"}
          </p>
          <p className="text-lg">
            <strong>Description:</strong> {job.description}
          </p>
          <p className="text-lg">
            <strong>Benefits:</strong>{" "}
            {job.benefits ? job.benefits.join(", ") : "N/A"}
          </p>
        </div>

        {/* Right Column with Logo and Contact Info */}
        <div className="bg-white rounded-lg shadow-md p-8 flex flex-col items-center">
          <img
            // href="https://th.bing.com/th/id/R.35720bbf29a0f0f1d48195bafdbedf7a?rik=1ArMFF%2fGA8AK1g&riu=http%3a%2f%2fshmector.com%2f_ph%2f13%2f188552034.png&ehk=4W3VAJ3Rgszg4unVrkViPToNE%2b15%2bt3SxRm%2b2VYCdIk%3d&risl=&pid=ImgRaw&r=0"
            src="https://th.bing.com/th/id/R.35720bbf29a0f0f1d48195bafdbedf7a?rik=1ArMFF%2fGA8AK1g&riu=http%3a%2f%2fshmector.com%2f_ph%2f13%2f188552034.png&ehk=4W3VAJ3Rgszg4unVrkViPToNE%2b15%2bt3SxRm%2b2VYCdIk%3d&risl=&pid=ImgRaw&r=0"
            alt="Company Logo"
            className="h-56 w-56 object-cover mb-4 rounded-full"
          />
          <p className="text-lg font-semibold text-gray-700">
            {job.companyName}
          </p>
          <p className="text-md text-gray-500 mb-6">{job.jobLocation}</p>
          <div className="border-t border-gray-200 w-full pt-4 mt-4">
            <h3 className="font-bold text-lg text-gray-800 mb-2">
              Contact Information
            </h3>
            <p>Email: {job.postedBy}</p>
            <p>Phone: (Add phone number if available)</p>
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <footer className="bg-white rounded-lg shadow-md p-8 mt-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-gray-600">
          <div>
            <h3 className="font-bold text-lg mb-2">Company Information</h3>
            <p>{job.companyName}</p>
            <p>Headquarters: {job.jobLocation}</p>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Contact Us</h3>
            <p>Email: {job.postedBy}</p>
            <p>Phone: (Add phone number)</p>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Follow Us</h3>
            <p>Facebook | Twitter | LinkedIn</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default JobDetails;
